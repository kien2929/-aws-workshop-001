#!/bin/bash

# Tìm file JAR mới nhất trong thư mục đích
JAR_FILE=$(ls -t /home/ec2-user/app/*.jar | head -n 1)

# Dừng ứng dụng hiện tại nếu có
sudo pkill -f 'java -jar' || true

# Khởi động ứng dụng mới từ file JAR đã tìm được ở chế độ nền
#!/bin/bash

# Tìm file JAR mới nhất trong thư mục đích
JAR_FILE=$(ls -t /home/ec2-user/app/*.jar | head -n 1)

# Dừng ứng dụng hiện tại nếu có
sudo pkill -f 'java -jar' || true

# Khởi động ứng dụng mới từ file JAR đã tìm được ở chế độ nền
nohup java -jar "$JAR_FILE" > /dev/null 2>&1 &

# In ra thông báo thành công
echo "Ứng dụng đã được khởi động lại thành công."
